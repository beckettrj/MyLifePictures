import React, { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Enhanced error boundary for better debugging
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error('💥 React Error Boundary caught an error:', error, errorInfo);
    this.setState({ errorInfo });
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center p-8 max-w-2xl">
            <h1 className="text-2xl font-bold text-red-600 mb-4">Application Error</h1>
            <p className="text-gray-600 mb-4">
              The application encountered an error. This is likely due to a configuration issue.
            </p>
            
            <div className="space-y-4">
              <button
                onClick={() => window.location.reload()}
                className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 mr-4"
              >
                Reload Application
              </button>
              
              <button
                onClick={() => {
                  // Clear all localStorage to reset app state
                  localStorage.clear();
                  window.location.reload();
                }}
                className="px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700"
              >
                Reset & Reload
              </button>
            </div>

            <details className="mt-6 text-left">
              <summary className="cursor-pointer text-sm text-gray-500 mb-2">
                Show Error Details
              </summary>
              <div className="bg-gray-100 p-4 rounded text-xs overflow-auto">
                <div className="mb-2">
                  <strong>Error:</strong>
                  <pre className="mt-1">{this.state.error?.toString()}</pre>
                </div>
                {this.state.errorInfo && (
                  <div>
                    <strong>Component Stack:</strong>
                    <pre className="mt-1">{this.state.errorInfo.componentStack}</pre>
                  </div>
                )}
              </div>
            </details>

            <div className="mt-6 p-4 bg-blue-50 rounded-lg text-sm text-blue-800">
              <p><strong>Common fixes:</strong></p>
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>Check your .env file has the correct Supabase credentials</li>
                <li>Ensure VITE_SUPABASE_ANON_KEY is set correctly</li>
                <li>Try the "Reset & Reload" button to clear cached data</li>
                <li>Check the browser console for more detailed error messages</li>
              </ul>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

// Initialize app with better error handling
try {
  const root = createRoot(document.getElementById('root')!);

  root.render(
    <StrictMode>
      <ErrorBoundary>
        <App />
      </ErrorBoundary>
    </StrictMode>
  );
} catch (error) {
  console.error('💥 Failed to initialize React app:', error);
  
  // Fallback error display
  document.getElementById('root')!.innerHTML = `
    <div style="min-height: 100vh; display: flex; align-items: center; justify-content: center; font-family: system-ui;">
      <div style="text-align: center; padding: 2rem; max-width: 500px;">
        <h1 style="color: #dc2626; margin-bottom: 1rem;">Failed to Load Application</h1>
        <p style="color: #6b7280; margin-bottom: 2rem;">
          The application failed to initialize. This is likely a configuration issue.
        </p>
        <button 
          onclick="window.location.reload()" 
          style="background: #3b82f6; color: white; padding: 0.5rem 1rem; border: none; border-radius: 0.375rem; cursor: pointer;"
        >
          Reload Page
        </button>
        <div style="margin-top: 2rem; padding: 1rem; background: #f3f4f6; border-radius: 0.375rem; text-align: left;">
          <strong>Error:</strong>
          <pre style="margin-top: 0.5rem; font-size: 0.75rem; overflow: auto;">${error}</pre>
        </div>
      </div>
    </div>
  `;
}